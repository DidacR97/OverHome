package com.overhome.modules;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserPermissionDAOImplement implements UserPermissionDAO {
	private static String GETNAME = "SELECT id FROM OH_USER"
			+ " WHERE UPPER(NAME) = ?";
	private static String GETID = "SELECT OBJECT_ID FROM OH_USER_PERMISSION"
			+ " WHERE USER_ID = ? AND OBJECT_ID like ?";

	@Override
	public int readName(String userName) throws Exception{
		PreparedStatement sentence = null;
		ResultSet result = null;
		int user = -1;
		try{
			sentence = ConnectionManager.getConnection().prepareStatement(GETNAME);
			sentence.setString(1, userName);
			result = sentence.executeQuery();

			while (result.next()){
				user = result.getInt(1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			if(sentence != null){
				try {
					sentence.close();
				} catch (SQLException e) {
					throw new Exception("Error en MySQL", e);
				}
			}
		}
		return user;
	}

	@Override
	public boolean readID(String objectID, int userID) throws Exception{
		PreparedStatement sentence = null;
		ResultSet result = null;
		String id = null;
		boolean ok = false;
		try{
			sentence = ConnectionManager.getConnection().prepareStatement(GETID);
			sentence.setInt(1, userID);
			sentence.setString(2, objectID);
			result = sentence.executeQuery();

			while (result.next()){
				id = result.getString(1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			if(sentence != null){
				try {
					sentence.close();
				} catch (SQLException e) {
					throw new Exception("Error en MySQL", e);
				}
			}
		}

		if(id != null){
			ok = true;
		}

		return ok;
	}
}