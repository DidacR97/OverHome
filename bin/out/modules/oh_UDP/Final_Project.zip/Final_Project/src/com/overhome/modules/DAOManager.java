package com.overhome.modules;

public class DAOManager {

	private static ItemDAO itemDAO;
	private static UserPermissionDAO userPermissionDAO;

	public static ItemDAO getItemDAO() {
		if(itemDAO == null){
			itemDAO = new ItemDAOImplement();
		}
		return itemDAO;
	}

	public static UserPermissionDAO getuserPermissionDAO() {
		if(userPermissionDAO == null){
			userPermissionDAO = new UserPermissionDAOImplement();
		}
		return userPermissionDAO;
	}
}
