package com.overhome.modules;

public interface UserPermissionDAO {
	public int readName(String userName) throws Exception;
	public boolean readID(String objectID, int userID) throws Exception;
}
