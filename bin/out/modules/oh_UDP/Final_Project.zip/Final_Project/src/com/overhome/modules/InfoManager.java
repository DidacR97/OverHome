package com.overhome.modules;

public class InfoManager {
	public static boolean updateInfo(String data){
		String[] action = data.split(";");
		int value = 0;

		if((action.length == 2 && action != null) && userPermissionAutentication(action[0], action[1])){
			try {
				value = DAOManager.getItemDAO().read(action[0]);
				if(value == 0 || value == 1){
					switch(value){
						case 0: value = 1;
							break;

						case 1: value = 0;
							break;
					}

				DAOManager.getItemDAO().updateValue(value, action[0]);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return true;
		}
		return false;
	}

	public static boolean userPermissionAutentication(String objectID, String userName){
		int userID;
		boolean ok = false;

		try {
			userID = DAOManager.getuserPermissionDAO().readName(userName);

			ok = DAOManager.getuserPermissionDAO().readID(objectID, userID);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return ok;
	}
}
