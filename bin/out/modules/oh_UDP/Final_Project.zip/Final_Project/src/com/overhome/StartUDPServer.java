package com.overhome;

import com.overhome.modules.InfoManager;

public class StartUDPServer {

	public static void main(String[] args) {
		InfoManager.updateInfo("00010001;Didac");
	}
}