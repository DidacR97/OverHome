SISTEMA SERVIDOR WINDOWS
IP publica estatica servidor: 35.204.23.49
estar� activo al menos hasta el dia de la presentaci�n.

SISTEMA CLIENTE raspberry (se puede ejecutar esta prueba tambien en un pc normal)
Con Client.jar y pinController.sh en la misma carpeta se ejecuta Client.jar en una raspberry.
Se tendr� que ver en tiempo real los valores de cada objeto por consola.
Abrir en el navegador la pagina web en 35.204.23.49.
Entrar con el usuario/contrase�a guest/guest
Pulsar en BEDROOM y luego en una de las 4 cajas a la derecha para activar/desactivar un objeto.
nota: la web se reinicia cada 1,5 segundos, si se pulsa mientras esta reiniciando no har� nada.
nota: el objeto 12-laptop nunca se pondr� en verde ya que el usuario guest no tiene permisos para encenderlo.