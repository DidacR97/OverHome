-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Temps de generació: 31-05-2018 a les 17:58:58
-- Versió del servidor: 5.5.45
-- Versió de PHP: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de dades: `overhome`
--

-- --------------------------------------------------------

--
-- Estructura de la taula `oh_archive`
--

CREATE TABLE `oh_archive` (
  `id` int(11) NOT NULL,
  `OBJECT_ID` int(11) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `VALUE` int(4) NOT NULL,
  `DATE` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Registro cronológico de las acciones realizadas por los usua';

-- --------------------------------------------------------

--
-- Estructura de la taula `oh_object`
--

CREATE TABLE `oh_object` (
  `id` varchar(8) NOT NULL,
  `DESCRIPTION` varchar(50) DEFAULT NULL,
  `ZONE_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Objetos de la casa';

--
-- Bolcament de dades per a la taula `oh_object`
--

INSERT INTO `oh_object` (`id`, `DESCRIPTION`, `ZONE_ID`) VALUES
('00010001', '01-Main_Light', 4),
('00010002', '02-Exit_door', 4),
('00010003', '03-Kitchen_door', 4),
('00010004', '04-Bedroom_door', 4),
('00010005', '05-Bathroom_door', 4),
('00020001', '06-Main_Light', 5),
('00020002', '07-Fridge', 5),
('00020003', '08-Oven', 5),
('00030001', '09-Main_Light', 3),
('00030002', '10-Light', 3),
('00030003', '11-Light2', 3),
('00030004', '12-Laptop', 3),
('00040001', '13-Main_Light', 2),
('00040002', '14-Shower', 2);

-- --------------------------------------------------------

--
-- Estructura de la taula `oh_user`
--

CREATE TABLE `oh_user` (
  `id` int(11) NOT NULL,
  `NAME` varchar(50) NOT NULL,
  `PASSWORD` varchar(50) DEFAULT NULL,
  `REG_DATE` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Usuarios que interactuarán con la casa.';

--
-- Bolcament de dades per a la taula `oh_user`
--

INSERT INTO `oh_user` (`id`, `NAME`, `PASSWORD`, `REG_DATE`) VALUES
(1, 'didac', 'admin', NULL),
(2, 'samuel', 'admin', NULL),
(3, 'adrian', 'admin', NULL),
(4, 'guest', 'guest', NULL),
(5, 'gordo;', 'gorda-', NULL);

-- --------------------------------------------------------

--
-- Estructura de la taula `oh_user_permission`
--

CREATE TABLE `oh_user_permission` (
  `USER_ID` int(11) NOT NULL,
  `OBJECT_ID` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Bolcament de dades per a la taula `oh_user_permission`
--

INSERT INTO `oh_user_permission` (`USER_ID`, `OBJECT_ID`) VALUES
(1, '00010001'),
(2, '00010001'),
(3, '00010001'),
(4, '00010001'),
(1, '00010002'),
(2, '00010002'),
(3, '00010002'),
(4, '00010002'),
(1, '00010003'),
(2, '00010003'),
(3, '00010003'),
(4, '00010003'),
(1, '00010004'),
(2, '00010004'),
(3, '00010004'),
(4, '00010004'),
(1, '00010005'),
(2, '00010005'),
(3, '00010005'),
(4, '00010005'),
(1, '00020001'),
(2, '00020001'),
(3, '00020001'),
(4, '00020001'),
(1, '00020002'),
(2, '00020002'),
(3, '00020002'),
(4, '00020002'),
(1, '00020003'),
(2, '00020003'),
(3, '00020003'),
(4, '00020003'),
(1, '00030001'),
(2, '00030001'),
(3, '00030001'),
(4, '00030001'),
(1, '00030002'),
(2, '00030002'),
(3, '00030002'),
(4, '00030002'),
(1, '00030003'),
(2, '00030003'),
(3, '00030003'),
(4, '00030003'),
(1, '00030004'),
(2, '00030004'),
(3, '00030004'),
(1, '00040001'),
(2, '00040001'),
(3, '00040001'),
(4, '00040001'),
(1, '00040002'),
(2, '00040002'),
(3, '00040002'),
(4, '00040002');

-- --------------------------------------------------------

--
-- Estructura de la taula `oh_value`
--

CREATE TABLE `oh_value` (
  `id` int(11) NOT NULL,
  `OBJECT_ID` varchar(8) NOT NULL,
  `LAST_UPDATE` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `LAST_USER` int(11) DEFAULT NULL,
  `ARCHIVE` int(4) NOT NULL DEFAULT '0',
  `VALUE` int(5) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Valores temporales de los objetos de la casa.';

--
-- Bolcament de dades per a la taula `oh_value`
--

INSERT INTO `oh_value` (`id`, `OBJECT_ID`, `LAST_UPDATE`, `LAST_USER`, `ARCHIVE`, `VALUE`) VALUES
(15, '00010001', '2018-05-31 16:47:55', NULL, 0, 0),
(16, '00010002', '2018-05-30 12:09:10', NULL, 0, 0),
(17, '00010003', '2018-05-30 12:09:12', NULL, 0, 0),
(18, '00010004', '2018-05-30 12:07:55', NULL, 0, 0),
(19, '00010005', '2018-05-28 17:41:43', NULL, 0, 0),
(20, '00020001', '2018-05-29 17:21:38', NULL, 0, 0),
(21, '00020002', '2018-05-29 13:35:00', NULL, 0, 0),
(22, '00020003', '2018-05-28 17:41:46', NULL, 0, 0),
(23, '00030001', '2018-05-30 20:02:46', NULL, 0, 0),
(24, '00030002', '2018-05-30 19:56:52', NULL, 0, 0),
(25, '00030003', '2018-05-30 19:57:06', NULL, 0, 0),
(26, '00030004', '2018-05-30 12:09:37', NULL, 0, 0),
(27, '00040001', '2018-05-28 21:33:47', NULL, 0, 0),
(28, '00040002', '2018-05-28 17:41:01', NULL, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de la taula `oh_zone`
--

CREATE TABLE `oh_zone` (
  `id` int(11) NOT NULL,
  `NAME` varchar(50) NOT NULL,
  `DESCRIPTION` varchar(50) DEFAULT NULL,
  `SVG_NAME` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Zonas de la casa.';

--
-- Bolcament de dades per a la taula `oh_zone`
--

INSERT INTO `oh_zone` (`id`, `NAME`, `DESCRIPTION`, `SVG_NAME`) VALUES
(1, 'general_0001', 'General', 'general_0001.svg'),
(2, 'bathroom_0001', 'Bathroom', 'bathroom_0001.svg'),
(3, 'bedroom_0001', 'Bedroom', 'bedroom_0001.svg'),
(4, 'dinningroom_0001', 'Dinning Room', 'dinningroom_0001.svg'),
(5, 'kitchen_0001', 'Kitchen', 'kitchen_0001.svg');

--
-- Índexs per a les taules bolcades
--

--
-- Índexs per a la taula `oh_archive`
--
ALTER TABLE `oh_archive`
  ADD PRIMARY KEY (`id`);

--
-- Índexs per a la taula `oh_object`
--
ALTER TABLE `oh_object`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ZONE_ID` (`ZONE_ID`);

--
-- Índexs per a la taula `oh_user`
--
ALTER TABLE `oh_user`
  ADD PRIMARY KEY (`id`);

--
-- Índexs per a la taula `oh_user_permission`
--
ALTER TABLE `oh_user_permission`
  ADD PRIMARY KEY (`USER_ID`,`OBJECT_ID`),
  ADD KEY `OBJECT_PERMISSION` (`OBJECT_ID`);

--
-- Índexs per a la taula `oh_value`
--
ALTER TABLE `oh_value`
  ADD PRIMARY KEY (`id`),
  ADD KEY `OBJECT_ID` (`OBJECT_ID`),
  ADD KEY `LAST_USER` (`LAST_USER`);

--
-- Índexs per a la taula `oh_zone`
--
ALTER TABLE `oh_zone`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per les taules bolcades
--

--
-- AUTO_INCREMENT per la taula `oh_archive`
--
ALTER TABLE `oh_archive`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT per la taula `oh_user`
--
ALTER TABLE `oh_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT per la taula `oh_value`
--
ALTER TABLE `oh_value`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT per la taula `oh_zone`
--
ALTER TABLE `oh_zone`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restriccions per a les taules bolcades
--

--
-- Restriccions per a la taula `oh_object`
--
ALTER TABLE `oh_object`
  ADD CONSTRAINT `oh_object_ibfk_1` FOREIGN KEY (`ZONE_ID`) REFERENCES `oh_zone` (`id`);

--
-- Restriccions per a la taula `oh_user_permission`
--
ALTER TABLE `oh_user_permission`
  ADD CONSTRAINT `OBJECT_PERMISSION` FOREIGN KEY (`OBJECT_ID`) REFERENCES `oh_object` (`id`),
  ADD CONSTRAINT `USER_PERMISSION` FOREIGN KEY (`USER_ID`) REFERENCES `oh_user` (`id`);

--
-- Restriccions per a la taula `oh_value`
--
ALTER TABLE `oh_value`
  ADD CONSTRAINT `oh_value_ibfk_1` FOREIGN KEY (`OBJECT_ID`) REFERENCES `oh_object` (`id`),
  ADD CONSTRAINT `oh_value_ibfk_2` FOREIGN KEY (`LAST_USER`) REFERENCES `oh_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
